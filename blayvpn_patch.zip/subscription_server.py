"""
Subscription server — отдаёт персональную подписку пользователю.

GET /sub/{user_tg_id}
  → возвращает base64-список конфигов:
    1. Все конфиги из Marzban (sub_url приложение подгружает через redirect)
    2. Pool-конфиги (5 RU + 5 foreign) — прямо в ответе

При каждом GET (обновлении подписки в приложении):
  - pool-конфиги ротируются на новые случайные 5+5
  - Marzban sub_url остаётся неизменным
"""

import base64
import logging
from datetime import datetime

import aiohttp
from aiohttp import web
from sqlalchemy import select

from config import settings
from core.database import async_session_maker, Subscription
from core.pool_manager import get_pool_configs

logger = logging.getLogger(__name__)


async def _fetch_marzban_configs(sub_url: str) -> list:
    """Скачивает конфиги из Marzban sub_url и парсит их."""
    if not sub_url:
        return []
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(sub_url, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                if resp.status != 200:
                    return []
                raw = await resp.text()
                # Marzban отдаёт base64
                try:
                    decoded = base64.b64decode(raw.strip()).decode("utf-8")
                    return [l for l in decoded.splitlines() if l.strip()]
                except Exception:
                    return [l for l in raw.splitlines() if l.strip()]
    except Exception as e:
        logger.warning(f"Failed to fetch Marzban sub: {e}")
        return []


async def handle_subscription(request: web.Request) -> web.Response:
    """Отдаёт подписку пользователю."""
    user_tg_id_str = request.match_info.get("user_tg_id", "")
    try:
        user_tg_id = int(user_tg_id_str)
    except ValueError:
        return web.Response(status=404)

    async with async_session_maker() as session:
        result = await session.execute(
            select(Subscription).where(
                Subscription.user_tg_id == user_tg_id,
                Subscription.status == "active",
            ).order_by(Subscription.expires_at.desc())
        )
        sub = result.scalar_one_or_none()

    if not sub:
        # Красивый ответ — нет подписки
        expired_configs = [
            f"vless://00000000-0000-0000-0000-000000000000@127.0.0.1:1#❌ Нет активной подписки | Оформить: @VpnBlay_bot"
        ]
        encoded = base64.b64encode("\n".join(expired_configs).encode("utf-8")).decode("utf-8")
        return web.Response(
            text=encoded,
            content_type="text/plain",
            headers={
                "Profile-Title": "BlayVPN — Нет подписки",
                "Support-URL": "https://t.me/VpnBlay_bot",
            }
        )

    # Проверяем срок действия
    if sub.expires_at and sub.expires_at < datetime.utcnow():
        expires_str = sub.expires_at.strftime("%d.%m.%Y")
        expired_configs = [
            f"vless://00000000-0000-0000-0000-000000000000@127.0.0.1:1#❌ Подписка истекла {expires_str} | Продлить: @VpnBlay_bot"
        ]
        encoded = base64.b64encode("\n".join(expired_configs).encode("utf-8")).decode("utf-8")
        return web.Response(
            text=encoded,
            content_type="text/plain",
            headers={
                "Profile-Title": f"BlayVPN — Истекла {expires_str}",
                "Support-URL": "https://t.me/VpnBlay_bot",
            }
        )

    # 1. Конфиги из Marzban
    marzban_configs = await _fetch_marzban_configs(sub.sub_url)

    # 2. Ротируем pool-конфиги при каждом обновлении (новые случайные 5+5), с датой подписки
    pool_configs = await get_pool_configs(count_ru=5, count_foreign=5, expires_at=sub.expires_at)

    # Сохраняем новые pool-конфиги в подписку
    async with async_session_maker() as session:
        result = await session.execute(
            select(Subscription).where(
                Subscription.user_tg_id == user_tg_id,
                Subscription.status == "active",
            )
        )
        sub_to_update = result.scalar_one_or_none()
        if sub_to_update:
            sub_to_update.pool_configs = pool_configs
            await session.commit()

    # 3. Объединяем: pool-конфиги первыми (видны сразу), потом Marzban
    all_configs = pool_configs + marzban_configs

    if not all_configs:
        return web.Response(status=204)

    # Кодируем в base64 — стандартный формат подписки для v2rayNG/Nekobox/Hiddify
    encoded = base64.b64encode("\n".join(all_configs).encode("utf-8")).decode("utf-8")

    expires_str = sub.expires_at.strftime("%d.%m.%Y") if sub.expires_at else "∞"
    return web.Response(
        text=encoded,
        content_type="text/plain",
        headers={
            "Content-Disposition": f'attachment; filename="blayvpn_{user_tg_id}.txt"',
            "Profile-Title": f"BlayVPN | до {expires_str} | @VpnBlay_bot",
            "Support-URL": "https://t.me/VpnBlay_bot",
        }
    )


def create_subscription_app() -> web.Application:
    app = web.Application()
    app.router.add_get("/sub/{user_tg_id}", handle_subscription)
    return app
