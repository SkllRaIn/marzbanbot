"""
Subscription server — отдаёт персональную подписку пользователю.

GET /sub/{user_tg_id}
  → возвращает base64-список конфигов:
    1. Все конфиги из Marzban — переименованы в BlayVPN-стиль
    2. Pool-конфиги (5 RU + 5 foreign) — тоже переименованы

При каждом GET (обновлении подписки в приложении):
  - pool-конфиги ротируются на новые случайные 5+5
  - Marzban sub_url остаётся неизменным
"""

import base64
import logging
import re
import urllib.parse
from datetime import datetime

import aiohttp
from aiohttp import web
from sqlalchemy import select

from config import settings
from core.database import async_session_maker, Subscription
from core.pool_manager import get_pool_configs, COUNTRY_EMOJI_MAP, BOT_LINK, BRAND

logger = logging.getLogger(__name__)

# Протоколы которые умеем переименовывать
_PROTO_RE = re.compile(r'^(vless|vmess|trojan|ss|hysteria2|hysteria|tuic)://', re.IGNORECASE)
_FLAG_RE = re.compile(r'[\U0001F1E0-\U0001F1FF]{2}')

# Английские названия городов/стран → русское с флагом
_EN_COUNTRY_MAP = {
    "russia": "🇷🇺 Россия",
    "st petersburg": "🇷🇺 Россия",
    "saint petersburg": "🇷🇺 Россия",
    "moscow": "🇷🇺 Россия",
    "germany": "🇩🇪 Германия",
    "frankfurt": "🇩🇪 Германия",
    "berlin": "🇩🇪 Германия",
    "france": "🇫🇷 Франция",
    "paris": "🇫🇷 Франция",
    "netherlands": "🇳🇱 Нидерланды",
    "amsterdam": "🇳🇱 Нидерланды",
    "eygelshoven": "🇳🇱 Нидерланды",
    "finland": "🇫🇮 Финляндия",
    "helsinki": "🇫🇮 Финляндия",
    "sweden": "🇸🇪 Швеция",
    "stockholm": "🇸🇪 Швеция",
    "poland": "🇵🇱 Польша",
    "warsaw": "🇵🇱 Польша",
    "united states": "🇺🇸 США",
    "miami": "🇺🇸 США",
    "united kingdom": "🇬🇧 Великобритания",
    "london": "🇬🇧 Великобритания",
    "switzerland": "🇨🇭 Швейцария",
    "austria": "🇦🇹 Австрия",
    "czech": "🇨🇿 Чехия",
    "ukraine": "🇺🇦 Украина",
    "lithuania": "🇱🇹 Литва",
    "siauliai": "🇱🇹 Литва",
    "latvia": "🇱🇻 Латвия",
    "estonia": "🇪🇪 Эстония",
    "tallinn": "🇪🇪 Эстония",
    "bulgaria": "🇧🇬 Болгария",
    "romania": "🇷🇴 Румыния",
    "singapore": "🇸🇬 Сингапур",
    "japan": "🇯🇵 Япония",
    "korea": "🇰🇷 Корея",
    "turkey": "🇹🇷 Турция",
    "moldova": "🇲🇩 Молдова",
    "chisinau": "🇲🇩 Молдова",
    "greece": "🇬🇷 Греция",
    "thessaloniki": "🇬🇷 Греция",
    "belgium": "🇧🇪 Бельгия",
    "canada": "🇨🇦 Канада",
    "australia": "🇦🇺 Австралия",
    "hong kong": "🇭🇰 Гонконг",
    "denmark": "🇩🇰 Дания",
    "norway": "🇳🇴 Норвегия",
    "italy": "🇮🇹 Италия",
    "spain": "🇪🇸 Испания",
    "portugal": "🇵🇹 Португалия",
    "serbia": "🇷🇸 Сербия",
    "armenia": "🇦🇲 Армения",
    "georgia": "🇬🇪 Грузия",
    "kazakhstan": "🇰🇿 Казахстан",
    "azerbaijan": "🇦🇿 Азербайджан",
}

# Безопасные символы для url-encode метки
_SAFE_CHARS = " ,.|#()🇦🇧🇨🇩🇪🇫🇬🇭🇮🇯🇰🇱🇲🇳🇴🇵🇶🇷🇸🇹🇺🇻🇼🇽🇾🇿🌐❌⚠️✅-"


def _rename_config(cfg: str, index: int, expires_at=None) -> str:
    """
    Переименовывает ЛЮБОЙ конфиг в формат:
    BlayVPN | 🇩🇪 Германия #3 | до 01.06.2025 | @VpnBlay_bot
    """
    cfg = cfg.strip()
    if not _PROTO_RE.match(cfg):
        return cfg  # не конфиг — не трогаем

    # Извлекаем текущую метку после #
    if "#" in cfg:
        base = cfg.rsplit("#", 1)[0]
        raw_label = urllib.parse.unquote(cfg.rsplit("#", 1)[1].strip())
    else:
        base = cfg
        raw_label = ""

    label_lower = raw_label.lower()
    country_name = None

    # 1. Флаги-эмодзи
    flags = _FLAG_RE.findall(raw_label)
    for flag in flags:
        if flag in COUNTRY_EMOJI_MAP:
            country_name = COUNTRY_EMOJI_MAP[flag]
            break

    # 2. Английские слова
    if not country_name:
        for keyword, cname in _EN_COUNTRY_MAP.items():
            if keyword in label_lower:
                country_name = cname
                break

    # 3. Anycast
    if not country_name and "anycast" in label_lower:
        country_name = "🌐 Anycast Global"

    # 4. Fallback
    if not country_name:
        country_name = "🌐 Сервер"

    # Срок действия
    expires_part = ""
    if expires_at:
        try:
            expires_part = f" | до {expires_at.strftime('%d.%m.%Y')}"
        except Exception:
            pass

    new_label = f"{BRAND} | {country_name} #{index}{expires_part} | {BOT_LINK}"
    return base + "#" + urllib.parse.quote(new_label, safe=_SAFE_CHARS)


async def _fetch_marzban_configs(sub_url: str) -> list:
    """Скачивает конфиги из Marzban sub_url и парсит их."""
    if not sub_url:
        return []
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(sub_url, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                if resp.status != 200:
                    return []
                raw = await resp.text()
                try:
                    decoded = base64.b64decode(raw.strip()).decode("utf-8")
                    return [l for l in decoded.splitlines() if l.strip()]
                except Exception:
                    return [l for l in raw.splitlines() if l.strip()]
    except Exception as e:
        logger.warning(f"Failed to fetch Marzban sub: {e}")
        return []


async def handle_subscription(request: web.Request) -> web.Response:
    """Отдаёт подписку пользователю."""
    user_tg_id_str = request.match_info.get("user_tg_id", "")
    try:
        user_tg_id = int(user_tg_id_str)
    except ValueError:
        return web.Response(status=404)

    async with async_session_maker() as session:
        result = await session.execute(
            select(Subscription).where(
                Subscription.user_tg_id == user_tg_id,
                Subscription.status == "active",
            ).order_by(Subscription.expires_at.desc())
        )
        sub = result.scalar_one_or_none()

    if not sub:
        expired_configs = [
            "vless://00000000-0000-0000-0000-000000000000@127.0.0.1:1#"
            + urllib.parse.quote("❌ Нет активной подписки | Оформить: @VpnBlay_bot", safe=_SAFE_CHARS)
        ]
        encoded = base64.b64encode("\n".join(expired_configs).encode("utf-8")).decode("utf-8")
        return web.Response(
            text=encoded,
            content_type="text/plain",
            headers={
                "Profile-Title": "BlayVPN — Нет подписки",
                "Support-URL": "https://t.me/VpnBlay_bot",
            }
        )

    # Проверяем срок действия
    if sub.expires_at and sub.expires_at < datetime.utcnow():
        expires_str = sub.expires_at.strftime("%d.%m.%Y")
        expired_configs = [
            "vless://00000000-0000-0000-0000-000000000000@127.0.0.1:1#"
            + urllib.parse.quote(f"❌ Подписка истекла {expires_str} | Продлить: @VpnBlay_bot", safe=_SAFE_CHARS)
        ]
        encoded = base64.b64encode("\n".join(expired_configs).encode("utf-8")).decode("utf-8")
        return web.Response(
            text=encoded,
            content_type="text/plain",
            headers={
                "Profile-Title": f"BlayVPN — Истекла {expires_str}",
                "Support-URL": "https://t.me/VpnBlay_bot",
            }
        )

    # 1. Конфиги из Marzban — скачиваем и сразу переименовываем
    raw_marzban = await _fetch_marzban_configs(sub.sub_url)
    marzban_configs = [
        _rename_config(cfg, idx + 1, expires_at=sub.expires_at)
        for idx, cfg in enumerate(raw_marzban)
    ]

    # 2. Pool-конфиги (уже переименованы внутри get_pool_configs)
    pool_configs = await get_pool_configs(count_ru=5, count_foreign=5, expires_at=sub.expires_at)

    # Сохраняем pool-конфиги в подписку
    async with async_session_maker() as session:
        result = await session.execute(
            select(Subscription).where(
                Subscription.user_tg_id == user_tg_id,
                Subscription.status == "active",
            )
        )
        sub_to_update = result.scalar_one_or_none()
        if sub_to_update:
            sub_to_update.pool_configs = pool_configs
            await session.commit()

    # 3. Объединяем: pool первыми, потом Marzban
    all_configs = pool_configs + marzban_configs

    if not all_configs:
        return web.Response(status=204)

    encoded = base64.b64encode("\n".join(all_configs).encode("utf-8")).decode("utf-8")

    expires_str = sub.expires_at.strftime("%d.%m.%Y") if sub.expires_at else "∞"
    return web.Response(
        text=encoded,
        content_type="text/plain",
        headers={
            "Content-Disposition": f'attachment; filename="blayvpn_{user_tg_id}.txt"',
            "Profile-Title": f"BlayVPN | до {expires_str} | @VpnBlay_bot",
            "Support-URL": "https://t.me/VpnBlay_bot",
        }
    )


def create_subscription_app() -> web.Application:
    app = web.Application()
    app.router.add_get("/sub/{user_tg_id}", handle_subscription)
    return app
