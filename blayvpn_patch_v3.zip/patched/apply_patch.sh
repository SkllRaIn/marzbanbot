#!/bin/bash
# ============================================================
# BlayVPN patch — применяет все исправления
# Запускать: sudo bash apply_patch.sh
# ============================================================
set -e

APP_DIR="/opt/blayvpn"
PATCH_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "=== BlayVPN Patch ==="
echo "App dir: $APP_DIR"
echo "Patch dir: $PATCH_DIR"
echo ""

# Проверяем что мы в правильном месте
if [ ! -f "$APP_DIR/config.py" ]; then
    echo "ERROR: $APP_DIR/config.py не найден. Проверьте путь."
    exit 1
fi

# Бэкап
BACKUP_DIR="$APP_DIR/backup_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP_DIR"
echo "📦 Создаём бэкап в $BACKUP_DIR..."
cp "$APP_DIR/subscription_server.py" "$BACKUP_DIR/" 2>/dev/null || true
cp "$APP_DIR/core/scheduler.py" "$BACKUP_DIR/" 2>/dev/null || true
cp "$APP_DIR/core/marzban.py" "$BACKUP_DIR/" 2>/dev/null || true
cp "$APP_DIR/core/pool_manager.py" "$BACKUP_DIR/" 2>/dev/null || true
cp "$APP_DIR/bots/admin_bot/handlers/users.py" "$BACKUP_DIR/" 2>/dev/null || true

# Применяем патч
echo "🔧 Применяем исправления..."

cp "$PATCH_DIR/subscription_server.py" "$APP_DIR/subscription_server.py"
echo "  ✅ subscription_server.py"

cp "$PATCH_DIR/core/scheduler.py" "$APP_DIR/core/scheduler.py"
echo "  ✅ core/scheduler.py"

cp "$PATCH_DIR/core/marzban.py" "$APP_DIR/core/marzban.py"
echo "  ✅ core/marzban.py"

cp "$PATCH_DIR/core/pool_manager.py" "$APP_DIR/core/pool_manager.py"
echo "  ✅ core/pool_manager.py"

cp "$PATCH_DIR/bots/admin_bot/handlers/users.py" "$APP_DIR/bots/admin_bot/handlers/users.py"
echo "  ✅ bots/admin_bot/handlers/users.py"

# Перезапуск
echo ""
echo "🔄 Перезапускаем сервис..."
systemctl restart blayvpn
sleep 3
systemctl status blayvpn --no-pager | head -20

echo ""
echo "✅ Патч применён!"
echo ""
echo "Проверьте логи: journalctl -u blayvpn -f"
